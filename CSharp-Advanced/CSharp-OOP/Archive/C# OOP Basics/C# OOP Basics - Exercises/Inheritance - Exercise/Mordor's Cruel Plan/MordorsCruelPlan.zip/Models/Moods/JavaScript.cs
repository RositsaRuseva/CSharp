﻿using MordorsCruelPlan.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Models.Moods
{
    public class JavaScript : Mood
    {
        public JavaScript(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
