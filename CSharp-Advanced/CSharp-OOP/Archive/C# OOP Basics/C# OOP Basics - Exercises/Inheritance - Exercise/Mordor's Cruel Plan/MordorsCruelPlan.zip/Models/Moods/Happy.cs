﻿using MordorsCruelPlan.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MordorsCruelPlan.Models.Moods
{
    public class Happy : Mood
    {
        public Happy(int happinessPoints) : base(happinessPoints)
        {
        }
    }
}
