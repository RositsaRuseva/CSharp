﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Common
{
    public static class ExceptionMessages
    {
        public const string DOES_NOT_EAT_FOOD = "{0} does not eat {1}!";
    }
}
