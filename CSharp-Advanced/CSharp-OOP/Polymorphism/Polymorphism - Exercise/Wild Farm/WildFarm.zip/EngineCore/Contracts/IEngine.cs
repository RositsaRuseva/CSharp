﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.EngineCore.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
