﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Models.Contracts
{
    public interface IBaseHero
    {
    }
}
