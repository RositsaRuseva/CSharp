﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Common
{
    public enum HeroEnum
    {
        Druid,
        Paladin,
        Rogue,
        Warrior,
    }
}
