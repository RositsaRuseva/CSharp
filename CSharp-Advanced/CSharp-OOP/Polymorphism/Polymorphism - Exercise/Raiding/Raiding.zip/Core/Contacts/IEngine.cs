﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Core.Contacts
{
    public interface IEngine
    {
        public void Run();
    }
}
