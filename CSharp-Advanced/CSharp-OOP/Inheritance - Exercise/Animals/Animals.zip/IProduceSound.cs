﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    interface IProduceSound
    {
        string ProduceSound();
    }
}
